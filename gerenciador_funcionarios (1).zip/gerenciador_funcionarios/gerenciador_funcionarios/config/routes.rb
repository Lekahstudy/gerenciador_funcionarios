Rails.application.routes.draw do
  # Rotas padrões do Rails
  get "up" => "rails/health#show", as: :rails_health_check

  # Define as rotas para Funcionários
  resources :funcionarios
end
