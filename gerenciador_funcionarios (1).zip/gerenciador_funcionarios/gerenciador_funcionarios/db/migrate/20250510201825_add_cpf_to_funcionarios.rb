class AddCpfToFuncionarios < ActiveRecord::Migration[8.0]
  def change
    add_column :funcionarios, :cpf, :string
  end
end
