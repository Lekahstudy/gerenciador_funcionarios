class FuncionariosController < ApplicationController
  def index
    @funcionarios = Funcionario.all
    render json: @funcionarios
  end

  def update
    @funcionario = Funcionario.find(params[:id])
    if @funcionario.update(funcionario_params)
      render json: @funcionario
    else
      render json: @funcionario.errors, status: :unprocessable_entity
    end
  end

  private

  def funcionario_params
    params.require(:funcionario).permit(:nome, :cargo, :salario, :cpf)
  end
end
