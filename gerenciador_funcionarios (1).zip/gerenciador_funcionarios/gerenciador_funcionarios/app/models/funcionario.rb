class Funcionario < ApplicationRecord
    validates :cpf, uniqueness: true, allow_nil: true, length: { is: 11 }
end

